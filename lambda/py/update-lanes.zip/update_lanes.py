import os
import sys
import parser
import argparse
import json
import boto3
import logging
from botocore.exceptions import ClientError
import flatbuffers
import Lanes
import Lane
import Vec3
import PointValidity
import PointAnnotationStatus
import numpy as np
from shapely.geometry import LineString, Point, MultiPoint, box
from shapely.ops import nearest_points
from scipy.spatial import cKDTree
from io import BytesIO

def create_original_lanes(region, bucket, name):
    s3 = boto3.client('s3', region_name = region)
    try:
        s3.head_object(Bucket=bucket, Key='/'.join([name, '2_Truth', 'original-lanes.fb']))
        # file exists
    except ClientError:
        # file does not exist
        copy_source = {
            'Bucket': bucket,
            'Key': '/'.join([name, '2_Truth', 'lanes.fb'])
        }
        # write file
        s3.copy(copy_source, bucket, '/'.join([name, '2_Truth', 'original-lanes.fb']))
    
def write_buffer_to_s3(region, bucket, name, builder):
    output_data = builder.Output()
    size = len(output_data).to_bytes(4, byteorder='little', signed=True)
    bytes_array = bytearray(size) + output_data
    key = '/'.join([name, '2_Truth/lanes.fb'])
    s3 = boto3.client('s3', region_name = region)
    try:
        response = s3.put_object(Body=bytes_array, Bucket=bucket, Key=key)
    except ClientError as e:
        logging.error(e)

# def get_schema_from_s3(bucket, name, filename):
#     try:
#         key = '/'.join([name, '5_Schemas/Flatbuffer/GroundTruth', filename + '.py'])
#         s3 = boto3.resource('s3')
#         s3.Bucket(bucket).download_file(key, '/tmp/{}'.format(filename))
#         sys.path.insert(0, '/tmp/')
#         import filename
#     except ClientError:
#         import filename

def to_bytes(n, length, endianess='big'):
    h = '%x' % n
    s = ('0'*(len(h) % 2) + h).zfill(length*2).decode('hex')
    return s if endianess == 'big' else s[::-1]

def create_vector(builder, nparray, flag):
    numVals = nparray.shape[0]

    if flag == 'left':
        Lane.LaneStartLeftVector(builder, numVals)
        return vec3VectorBuilderHelper(builder, numVals, nparray)
    elif flag == 'right':
        Lane.LaneStartRightVector(builder, numVals)
        return vec3VectorBuilderHelper(builder, numVals, nparray)
    elif flag == 'spine':
        Lane.LaneStartSpineVector(builder, numVals)
        return vec3VectorBuilderHelper(builder, numVals, nparray)
    elif flag == 'create_left_point_validities':
        Lane.LaneStartLeftPointValidityVector(builder, numVals)
        return enumVectorBuilderHelper(builder, numVals)
    elif flag == 'create_right_point_validities':
        Lane.LaneStartRightPointValidityVector(builder, numVals)
        return enumVectorBuilderHelper(builder, numVals)
    elif flag == 'left_point_validities':
        Lane.LaneStartLeftPointValidityVector(builder, numVals)
        return pointValidityBuilderHelper(builder, numVals, nparray)
    elif flag == 'right_point_validities':
        Lane.LaneStartRightPointValidityVector(builder, numVals)
        return pointValidityBuilderHelper(builder, numVals, nparray)
    elif flag == 'left_point_annotation_statuses':
        Lane.LaneStartLeftPointAnnotationStatusVector(builder, numVals)
        return enumVectorBuilderHelper(builder, numVals, byte=1)
    elif flag == 'right_point_annotation_statuses':
        Lane.LaneStartRightPointAnnotationStatusVector(builder, numVals)
        return enumVectorBuilderHelper(builder, numVals, byte=1)
    
def vec3VectorBuilderHelper(builder, numVals, nparray):
    for i in range(numVals)[::-1]:
        val = Vec3.CreateVec3(builder, nparray[i, 0], nparray[i, 1], nparray[i, 2])
    vals = builder.EndVector(numVals)
    return vals

def enumVectorBuilderHelper(builder, numVals, byte=0):
    for i in range(numVals)[::-1]:
        builder.PrependByte(byte)
    vals = builder.EndVector(numVals)
    return vals
    
def pointValidityBuilderHelper(builder, numVals, nparray):
    for i in range(numVals)[::-1]:
        builder.PrependByte(nparray[i])
    vals = builder.EndVector(numVals)
    return vals


def outputFlatbuffer(laneSegments, region, bucket, name, leftPointValidity, rightPointValidity):
    createNew = True
    temp_lanes = []

    # get_schema_from_s3(bucket, name, 'Lanes')
    # get_schema_from_s3(bucket, name, 'Lane')
    # get_schema_from_s3(bucket, name, 'Vec3')

    i = 0
    for laneSegment in laneSegments:
        print(i)
        i += 1

        builder = flatbuffers.Builder(1024)

        lefts = create_vector(builder, laneSegment['left'], 'left')
        rights = create_vector(builder, laneSegment['right'], 'right')
        spines = create_vector(builder, laneSegment['spine'], 'spine')
        left_point_annotation_statuses = create_vector(builder, laneSegment['left'], 'left_point_annotation_statuses')
        right_point_annotation_statuses = create_vector(builder, laneSegment['right'], 'right_point_annotation_statuses')
        
        if len(leftPointValidity) == 0:
            left_point_validities = create_vector(builder, laneSegment['left'], 'create_left_point_validities')
        else:
            left_point_validities = create_vector(builder, np.array(leftPointValidity), 'left_point_validities')
        if len(rightPointValidity) == 0:
            right_point_validities = create_vector(builder, laneSegment['right'], 'create_right_point_validities')
        else:
            right_point_validities = create_vector(builder, np.array(rightPointValidity), 'right_point_validities')

        # Start Lane:
        Lane.LaneStart(builder)

        # Set ID:
        Lane.LaneAddId(builder, 0)

        # Add Lefts:
        Lane.LaneAddLeft(builder, lefts)

        # Add Rights:
        Lane.LaneAddRight(builder, rights)

        # Add Spine:
        Lane.LaneAddSpine(builder, spines)

        # Add PointValidity
        Lane.LaneAddLeftPointValidity(builder, left_point_validities)
        Lane.LaneAddRightPointValidity(builder, right_point_validities)
        
        # Add PointAnnotationStatus
        Lane.LaneAddLeftPointAnnotationStatus(builder, left_point_annotation_statuses)
        Lane.LaneAddRightPointAnnotationStatus(builder, right_point_annotation_statuses)

        lane = Lane.LaneEnd(builder)
        builder.Finish(lane)
        temp_lanes.append(lane)

        create_original_lanes(region, bucket, name)

        write_buffer_to_s3(region, bucket, name, builder)
        
def getXYZ(data):
    x = data['position']['x']
    y = data['position']['y']
    z = data['position']['z']
    return [x, y, z]
    
def get_heading(pt1, pt2):
    p1 = np.array(pt1).transpose()
    p2 = np.array(pt2).transpose()
    delta = p2-p1
    heading = np.arctan2(delta[1], delta[0])
    return heading

def min_angle(theta, bounds=[-np.pi, np.pi]):
    while theta < bounds[0]:
        theta += 2*np.pi
    while theta > bounds[1]:
        theta -= 2*np.pi
    return theta

def min_angle_diff(theta1, theta2, bounds=[-np.pi, np.pi]):
    delta = theta2 - theta1
    return min_angle(delta)
                    
def getUpdatedSpine(input):
    laneChangeNNRange = 5 # meters
    rightLaneNeighborPointsQueryNumber = 10 # number of neighbors
    laneChangeHeadingThresh = np.pi/4 # Radians
    prevPointSuppressionRadius = .1 # meters

    laneSegments = []
    laneLefts = []
    laneSpines = []
    laneRights = []

    leftData = input['left']
    rightData = input['right']

    # Get Left/Right Line Vertices
    for i in range(len(leftData)):
        laneLefts.append(  getXYZ(leftData[i]) )
    for i in range(len(rightData)):
        laneRights.append( getXYZ(rightData[i]) )

    # Compute Spine Vertices (using left lane as reference):
    rightLine = LineString(laneRights) # Create shapely linestring for right line
    kdtree = cKDTree(laneRights) # Create KD-Tree for right lane points as well
    lastIdx = len(laneLefts)-1
    for ii in range(lastIdx+1):
        p = laneLefts[ii]
        pt = Point(p)
        projPt = rightLine.interpolate(rightLine.project(pt))
        minLine = LineString([pt, projPt]) # Shortest line from pt to right line
        spinePt = minLine.interpolate(minLine.length/2)

        if ii != 0 and ii != lastIdx:
            lastPt = Point(laneLefts[ii-1])
            nextPt = Point(laneLefts[ii+1])
            lastHeading = get_heading(lastPt, pt)
            nextHeading = get_heading(pt, nextPt)

            leftHeadingDelta = min_angle_diff(lastHeading, nextHeading)

            if np.abs(leftHeadingDelta) > laneChangeHeadingThresh:


                # Get idxs of nearby right points
                dists_nn, idxs_nn = kdtree.query(p, rightLaneNeighborPointsQueryNumber)

                filterer = dists_nn <= laneChangeNNRange
                dists_nn = dists_nn[filterer]
                idxs_nn = idxs_nn[filterer]

                if len(idxs_nn) == 0:
                    continue

                idxs_nn_min = max(idxs_nn.min()-1, 0)
                idxs_nn_max = min(idxs_nn.max()+2, len(laneRights))

                idxs_nn = np.arange(idxs_nn_min, idxs_nn_max) # Closed set of points approximately within laneChangeNNRange of pt

                if len(idxs_nn) < 3:
                    print("Not Enough Neighbors for pt: [idx: {}, pos: {}]".format(ii, p))
                    continue

                # Find closest lane change point in right line:
                rightPts = np.array(laneRights)[idxs_nn]
                rightPtDeltas = np.diff(rightPts, axis=0)
                rightHeadings = np.arctan2(rightPtDeltas[:,1], rightPtDeltas[:,0])
                rightHeadingDeltas = np.array([min_angle(x) for x in np.diff(rightHeadings)])
                # rightHeadingDeltas = np.diff(rightHeadings)

                if rightHeadingDeltas.shape[0] == 0:
                    print("No RightHeadingDeltas for pt: [idx: {}, pos: {}]".format(ii, p))
                    continue

                leftRightHeadingDeltaSimilarity = np.abs(rightHeadingDeltas-leftHeadingDelta)
                bestRightHeadingIdx = leftRightHeadingDeltaSimilarity.argmin() + 1
                rightPtIdx = idxs_nn[bestRightHeadingIdx] # +1 inside []

                # Simple Solution (Just Compute Spine Point using the Right Lane Change Point and append):
                rightPt = Point(laneRights[rightPtIdx])
                minLine = LineString([pt, rightPt])
                spinePt2 = minLine.interpolate(minLine.length/2)

                p1 = np.array(laneSpines[-1][:2])
                p2 = np.array(spinePt2.xy).flatten()

                if np.linalg.norm((p2-p1)) > prevPointSuppressionRadius: # If spine point is farther than thresh from previous point append
                    laneSpines.append([spinePt2.x, spinePt2.y, spinePt2.z])
                    
        # Don't append lane spine if duplicate (within 10cm of last) or if going backwards:
        def should_append(spinePt):
            if len(laneSpines) < 1:
                return True

            p1 = np.array(laneSpines[-1])[:2]
            p2 = np.array(spinePt.xy).flatten()

            if np.linalg.norm(p2-p1) < prevPointSuppressionRadius:
                print("Skipping lane spine point-- too close to existing spine point")
                return False
            else:
                if len(laneSpines) >=2:
                    p0 = np.array(laneSpines[-2])[:2]

                    v1 = (p1-p0)[:2]
                    v2 = (p2-p1)[:2]

                    magV1 = np.linalg.norm(v1)
                    magV2 = np.linalg.norm(v2)

                    cosHeading = np.dot(v1, v2)/(magV1 * magV2)

                    if np.abs(cosHeading - (-1)) < .1:
                        print("Skipping lane spine point -- going backwards")
                        return False
                    else:
                        return True
                else:
                    return True
                    
        if should_append(spinePt):
            laneSpines.append([spinePt.x, spinePt.y, spinePt.z])

    # Convert to Numpy arrays:
    laneSpines = np.array(laneSpines[:len(laneSpines)])
    laneLefts = np.array(laneLefts[:len(laneLefts)])
    laneRights = np.array(laneRights[:len(laneRights)])

    laneSegments.append({
        "left": laneLefts,
        "right": laneRights,
        "spine": laneSpines
    })
    outputFlatbuffer(laneSegments, input["region"], input['bucket'], input['name'], input["leftPointValidity"], input["rightPointValidity"])
    

def multipoint_index(multipoint, point):
    for i in range(len(multipoint)):
        if (point.x == multipoint[i].x and point.y == multipoint[i].y):
            return i

    return None